---
sources:
  - "[[XML Schema (Schéma XML)]]"
---
> [!question] DTDs and XML Schemas both use XML syntax.
>> [!success]- Answer
>> False

> [!question] DTDs offer a wide range of data types for precise data validation.
>> [!success]- Answer
>> False

> [!question] XML Schema's namespace support is superior to that of DTDs.
>> [!success]- Answer
>> True

> [!question] XML Schema allows for creating custom data types.
>> [!success]- Answer
>> True

> [!question] The 'biblio.xsd' example shows how to define a simple bibliography structure using XML Schema.
>> [!success]- Answer
>> True

> [!question] The root element of an XML Schema document can be any element as long as it's in the XML Schema namespace.
>> [!success]- Answer
>> False

> [!question] The `targetNamespace` attribute in an XML Schema defines the namespace for the schema document itself.
>> [!success]- Answer
>> False

> [!question] The `xsi:schemaLocation` attribute is used to link an XML instance document to its schema.
>> [!success]- Answer
>> True

> [!question] Complex types in XML Schema can contain both child elements and attributes.
>> [!success]- Answer
>> True

> [!question] Simple content in XML Schema allows elements to have both text content and attributes.
>> [!success]- Answer
>> True

